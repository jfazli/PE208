/**
 * Java
 * 
 * Copyright 2013 IS2T. All rights reserved.
 * For demonstration purpose only.
 * IS2T PROPRIETARY. Use is subject to license terms.
 */
package com.is2t.appnote;

import com.is2t.hil.HIL;

public class SensorsDriver implements Runnable {

	/**
	 * Number of sensors.
	 */
	public static final int NB_SENSORS = 5;
	/**
	 * Sensors latest values.
	 */
	private int[] buffer;

	/**
	 * Default constructor.
	 */
	public SensorsDriver(int[] buffer) {
		this.buffer = buffer;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Runnable#run()
	 */
	@Override
	public void run() {
		System.out.println("[SimJPF] - update sensors values");
		for (int i = 0; i < NB_SENSORS; i++) {
			this.buffer[i] = i * 10;
		}
		// HIL process doesn't share same heaps than application. Therefore,
		// buffer doesn't refer same memory location.
		// In order to change values of the application buffer, HIL provides
		// following method to send new values at application.
		HIL.getInstance().flushContent(this.buffer);
		try {
			// Wait 750 ms so that application can read new buffer values
			// and modify them
			Thread.sleep(750);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println("[SimJPF] - Read sensors values : ");
		// Like buffer modification, read values need to refresh buffer content.
		HIL.getInstance().refreshContent(this.buffer);
		for (int i = 0; i < NB_SENSORS; i++) {
			System.out.println("[SimJPF] - Sensor_" + i + " = "
					+ this.buffer[i]);
		}
	}

}
