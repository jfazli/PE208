/**
 * Java
 * 
 * Copyright 2013 IS2T. All rights reserved.
 * For demonstration purpose only.
 * IS2T PROPRIETARY. Use is subject to license terms.
 */
package com.is2t.appnote;

public class NativesInterface {

	/**
	 * Native method used to retrieve number of sensors.
	 * 
	 * @return Number of plugged sensors.
	 */
	public static int getNumberOfSensors() {
		return SensorsDriver.NB_SENSORS;
	}

	/**
	 * Native method used to share buffer address.
	 * 
	 * @param buffer
	 *            Shared buffer.
	 */
	public static void init(int[] buffer) {
		SensorsDriver driver = new SensorsDriver(buffer);
		new Thread(driver).start();
	}

}
